jQuery(document).ready(function($) {

	if ($(".tg-features-carousel").length) {
		$(".tg-features-carousel").slick({
			slidesToShow: 3,
			slidesToScroll: 3,
			dots: false,
			arrows: true,
			autoplay: false,
			speed: 700,
			cssEase: "linear",
			infinite: false,
			responsive: [
				{
					breakpoint: 1440,
					settings: {
						slidesToShow: 3,
						slidesToScroll: 3,
						infinite: false,
						arrows: true,
						dots: false
					},
				},
				{
					breakpoint: 769,
					settings: {
						slidesToShow: 1,
						slidesToScroll: 1,
						infinite: false,
						arrows: false,
						dots: true
					},
				}
			],
		});
	}
	
});